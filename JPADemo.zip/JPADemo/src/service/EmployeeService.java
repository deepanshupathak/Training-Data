package service;

import dao.EmployeeDAO;
import dto.EmployeeDTO;

public class EmployeeService {

	public void addEmployee(EmployeeDTO emp)
	{
		EmployeeDAO empd=new EmployeeDAO();
		empd.addEmployeeDAO(emp);
	}
	public void getEmployee(int eid)
	{
		new EmployeeDAO().getEmployeeDTO(eid);
	}
	public EmployeeDTO updateEmployee(int id,String city)
	{
		
		return new EmployeeDAO().updateEmployeeDAO(id,city);
	}
	public void deleteEmployee(int id)
	{
		new EmployeeDAO().deleteEmployeeDAO(id);
	}
}
