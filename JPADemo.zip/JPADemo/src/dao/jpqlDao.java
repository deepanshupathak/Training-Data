package dao;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import dto.EmployeeEntity;

public class jpqlDao {

	public void getEmployees()
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=emf.createEntityManager();
		Query q=em.createQuery("select e from EmployeeEntity e where e.salary<50000");
		List<EmployeeEntity> list=q.getResultList();
		for(EmployeeEntity emp:list)
		{
			System.out.println(+emp.getEmpid()+" : "+emp.getEmpName()+" : "+emp.getSalary()+" : "+emp.getCity());
		}
		EmployeeEntity ent=(EmployeeEntity)q.getSingleResult();
		System.out.println(ent.getCity());
		Query q1=em.createQuery("delete from EmployeeEntity where empid=?1 AND city=?2");
		q1.setParameter(1, 6001);
		q1.setParameter(2, "Bhopal");
		em.getTransaction().begin();
		int r=q1.executeUpdate();
		em.getTransaction().commit();
		System.out.println(r);
		
		em.close();
		emf.close();
	}
}
