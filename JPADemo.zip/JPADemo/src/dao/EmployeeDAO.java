package dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import dto.EmployeeDTO;
import dto.EmployeeEntity;

public class EmployeeDAO {

	public void addEmployeeDAO(EmployeeDTO emp)
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=emf.createEntityManager();
		EmployeeEntity entity=new EmployeeEntity();
		//entity.setEmpid(emp.getEmpid());
		entity.setEmpName(emp.getEmpName());
		entity.setSalary(emp.getSalary());
		entity.setCity(emp.getCity());
	
		EntityTransaction tract=em.getTransaction();
		tract.begin();
		em.persist(entity);
		tract.commit();
		em.close();
		emf.close();
		System.out.println("inserted into employee table");
	}
	
	public void getEmployeeDTO(int id)
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=emf.createEntityManager();
		EmployeeEntity ent=em.find(EmployeeEntity.class,id);
		if(ent!=null)
		{
			System.out.println(ent.getEmpName()+" : "+ent.getSalary()+" : "+ent.getCity());
		}
		else
		{
			System.out.println("Search not found");
		}
		em.close();
		emf.close();
	}
	public EmployeeDTO updateEmployeeDAO(int id,String city)
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=emf.createEntityManager();
		EmployeeEntity ent=em.find(EmployeeEntity.class,id);
		if(ent!=null)
		{
			EntityTransaction et=em.getTransaction();
			et.begin();
			ent.setCity(city);
			et.commit();
			em.close();
			emf.close();
			EmployeeDTO empd=new EmployeeDTO();
			empd.setEmpid(ent.getEmpid());
			empd.setEmpName(ent.getEmpName());
			empd.setSalary(ent.getSalary());
			empd.setCity(ent.getCity());
			return empd;
		}
		else
		{
		return null;
		}	
	}
	public void deleteEmployeeDAO(int id)
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=emf.createEntityManager();
		EmployeeEntity ent=em.find(EmployeeEntity.class,id);
		if(ent!=null)
		{
			EntityTransaction et=em.getTransaction();
			et.begin();
			em.remove(ent);
			et.commit();
			em.close();
			emf.close();
		}
	}
}
