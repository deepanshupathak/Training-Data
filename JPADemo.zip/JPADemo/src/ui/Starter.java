package ui;

import dao.EmployeeDAO;
import dao.jpqlDao;
import dto.EmployeeDTO;
import service.EmployeeService;

public class Starter {

	public static void main(String[] args) {
		
		EmployeeDTO emp=new EmployeeDTO(); 
		//emp.setEmpid(5002);
		emp.setEmpName("Jai");
		emp.setSalary(40000);
		emp.setCity("Jaipur");
		new jpqlDao().getEmployees();
		//addEmployees(emp);
		//getEmployees(5001);
		//updateEmployees(5001,"bhopal");
		//deleteEmployees(5002);
	}
	public static void addEmployees(EmployeeDTO emp)
	{
		new EmployeeService().addEmployee(emp);
	}
	public static void getEmployees(int empid)
	{
		new EmployeeService().getEmployee(empid);
	}
	public static void updateEmployees(int id,String city)
	{
		EmployeeDTO empd=new EmployeeService().updateEmployee(id,city);
		System.out.println(empd.getEmpid()+" : "+empd.getEmpName()+" : "+empd.getSalary()+" : "+empd.getCity());
	}
	public static void deleteEmployees(int id)
	{
		new EmployeeService().deleteEmployee(id);
	}

}
