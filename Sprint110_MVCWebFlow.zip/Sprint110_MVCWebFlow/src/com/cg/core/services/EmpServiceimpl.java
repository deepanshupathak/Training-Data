package com.cg.core.services;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

@Service
@Scope("singleton")
public class EmpServiceimpl implements EmpService {

	@Override
	public String authenticate(String userName, String password) 
	{
		if(userName.equals("aa") && password.equals("bb"))
		{
			return "aa bb cc";
		}
			return null;
	}

}
