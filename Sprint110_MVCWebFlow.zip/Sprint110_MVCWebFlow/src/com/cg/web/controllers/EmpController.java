package com.cg.web.controllers;



import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
//http://localhost:9090/Sprint110_MVCWebFlow/empService/home.do
import org.springframework.web.servlet.ModelAndView;

import com.cg.core.services.EmpService;

@Controller
@RequestMapping("/empService")
public class EmpController 
{
	@Autowired
	private EmpService emp;
	
	@RequestMapping("/home.do")
	public String getHomePage()
	{
		return "Home";
	}
	@RequestMapping("/login.do")
	public String getLoginPage()
	{
		return "Login";
	}
	@RequestMapping("/authenticate.do")
	public ModelAndView getAuthenticatePage(
			@RequestParam("userName") String userName,
			@RequestParam("password") String password
			)
	{
		/*String userName=req.getParameter("userName");
		String password=req.getParameter("password");*/
		String fullName=emp.authenticate(userName, password);
		ModelAndView mAndV=null;
		if(fullName==null)
		{
			mAndV=new ModelAndView("Login");
			mAndV.addObject("msg","Authentication failed please try again");
		}
		else
		{
		System.out.println(userName+" : "+password);
		mAndV=new ModelAndView("MainMenu");
		mAndV.addObject("fullName",fullName);
		}
		return mAndV;
	}
 
}
